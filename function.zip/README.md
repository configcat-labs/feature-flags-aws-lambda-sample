# feature-flags-aws-lambda-sample
A companion repo for How to use feature flags with AWS Lambda
