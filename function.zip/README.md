# feature-flags-aws-lambda-sample

A companion repo for How to use feature flags with AWS Lambda

## References

- <https://docs.aws.amazon.com/lambda/latest/dg/nodejs-package.html>